Final Project
Shiven Sharma - 101272855 

Web Application - Ticketing / Tasking Management system.

Guests and admins alike are able to contribute data - that is the tickets of various
tasks that need reviewing.

Admin level privledges provide the current users of the application and 
are able to update the status of existing tasks in the database. 

Download & launch Instructions:

1. Download and extract the zip file and locate the directory the files are in.
2. Run 'npm install' to install all required node modules to run this application.
3. run 'node server.js' in the same directory the server.js file exists to run the application.

Testing Instructions:

You can access the http://localhost:3000/login where you can login with an existing user.
With valid credentials, you are then redirected to the tickets interface page where you can add new tickets.

Youtube Video LINK:
https://youtu.be/e0BGaNiF_sY

